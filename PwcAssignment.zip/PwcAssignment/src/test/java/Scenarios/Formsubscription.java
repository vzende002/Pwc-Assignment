//******Scenario-2******
//Given I navigate to the PwC Digital Pulse website
//And I am viewing the Home page
//When I click on "Subscribe"
//Then I am viewing the Subscribe page
//And Enter data in all the fields in the form
//And I will need to complete Google reCAPTCHA
//And I will verify that the submit button is enabled

package Scenarios;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Formsubscription {
	
	WebDriver driver;

	@Before
	public void creatDriver() {
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vzende002\\Downloads\\Selenium downloads\\Drivers\\chromedriver.exe");  
	     driver=new ChromeDriver();  
	     driver.manage().window().maximize();  
	     
	    }

	/*public void Browser_close() 
	{
		driver.close();
		driver.quit();
	}*/
	
	//@Test
	//Given I navigate to the PwC Digital Pulse website
	public void navigatetowebsite() {
		String url = ("https://www.pwc.com.au/digitalpulse/subscribe.html"); 
		 try
		 {
			 driver.get(url); 
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 System.out.println("Successfully navigate to the website");
		 }
		 catch(Exception e)
		 {
			 System.out.println("Error at navigating website");
		 }
		
	}

	//@Test
	//And I am viewing the Home page
	public void Viewhomepage()
	{
		String url = ("https://www.pwc.com.au/digitalpulse.html");  
	    driver.get(url);  
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String actualUrl = driver.getCurrentUrl();  
		       
		if (actualUrl.equals("https://www.pwc.com.au/digitalpulse.html"))
		{  
			System.out.println("Successfully view the home page");  
		}  
		else
		{  
			System.out.println("Failed to view home page");  
		}  
	}
	
	//When I click on "Subscribe"
	public void clickMethod() {
		try {
			
			String url = ("https://www.pwc.com.au/digitalpulse/subscribe.html"); 
			driver.get(url); 
			WebElement p=driver.findElement(By.xpath("(//*[@navigation-title='Subscribe'])[1]"));
			p.click();
			
			System.out.println("Successfully click Subscribe page");
		}
		
		catch(Exception e)
		{
			System.out.println("failed to click Subscribe page");
		}
	}
			
	//@Test
	//Then I am viewing the Subscribe page
	public void Viewsubscribepage()
	{
		String url1 = ("https://www.pwc.com.au/digitalpulse/subscribe.html");  
	    driver.get(url1);  
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String actualUrl1 = driver.getCurrentUrl();  
		       
		if (actualUrl1.equals("https://www.pwc.com.au/digitalpulse/subscribe.html"))
		{  
			System.out.println("Successfully view the subscribe page");  
		}  
		else
		{  
			System.out.println("Failed to view subscribe page");  
		}  
		
	}
	
	//@Test
	//And Enter data in all the fields in the form
	public void fill_data_in_form() {
		try {
				driver.switchTo().frame("sfmcform");
		
				WebElement firstname =driver.findElement(By.xpath("//input[@id='FirstName']"));
				firstname.sendKeys("Jon");
		
				WebElement lname= driver.findElement(By.xpath("//input[@id='LastName']"));
				lname.sendKeys("Deo");
		
				WebElement organisation= driver.findElement(By.xpath("//input[@id='Company']"));
				organisation.sendKeys("PwC");
				
				WebElement job_title= driver.findElement(By.xpath("//input[@id='JobTitle']"));
				job_title.sendKeys("Sr.Associate");
				
				WebElement email= driver.findElement(By.xpath("//input[@id='EmailAddress']"));
				email.sendKeys("jon.deo@pwc.com");
				
				WebElement state= driver.findElement(By.xpath("//select[@id='State']"));
				Select select=new Select(state);
				select.selectByValue("ACT");
				
				WebElement country= driver.findElement(By.xpath("//select[@id='Country']"));
				select =new Select(country);
				select.selectByValue("Australia");
				
				System.out.println("Completed subscribe form");
			}
			catch(Exception e) 
			{
				System.out.println("Failed to enter data in all the fields");
			}
		}
		
	//@Test
	//And I will need to complete Google reCAPTCHA
	public void complete_Google_recaptcha() {
		
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[starts-with(@name,'a-')]")));
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='recaptcha-anchor']")));
			element.click();
			
			System.out.println("completed google Captcha");
		}
		catch(Exception e) 
		{
			System.out.println("Failed to complete Google reCAPTCHA");
		}
	}
	
	//And I will verify that the submit button is enabled
	//@Test
	public void verify_submit_button_is_enabled() {
		
		/*Boolean nn =driver.findElement(By.xpath("//input[@id='btn-submit']")).isEnabled();
		if(nn) 
	     {
	           System.out.println("Submit button is enabled");
	     }
	     else 
	     {
	           System.out.println("Submit button is not enabled");
	     }*/
		
		try
		{
			WebElement e = driver.findElement(By.id("btn-submit"));
			boolean actualvalue = e.isEnabled();
			if(actualvalue)
				System.out.println("Submit button is enabled");
			else
				throw new Exception("Submit button is disabled");
		}
		catch(Exception e){
			System.out.println("Submit button is enabled");
		}
	}
	     
	@Test
	public void subscriptionformmethod(){
		
		navigatetowebsite();
		Viewhomepage();
		clickMethod();
		Viewsubscribepage();
		fill_data_in_form() ;
		complete_Google_recaptcha();
		verify_submit_button_is_enabled();
		
		driver.close();
	}
}
