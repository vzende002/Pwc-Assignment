//******Scenario-1******
//Given I navigate to the PwC Digital Pulse website 
//When I am viewing the ‘Home’ page 
//Then I am presented with 3 columns of articles
//And The ‘left’ column is displaying 2 articles 
//And the ‘middle’ column is displaying 1 articles 
//And The ‘right’ column is displaying 4 articles

package Scenarios;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class homepageWithArticle {

WebDriver driver;

@Before
public void creatDriver() {
	
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vzende002\\Downloads\\Selenium downloads\\Drivers\\chromedriver.exe");  
     driver=new ChromeDriver();  
     driver.manage().window().maximize();  
     }

public void Browser_close() 
{
	driver.close();
	driver.quit();
}

//@Test
public void navigatetowebsite() {
	String url = ("https://www.pwc.com.au/digitalpulse/"); 
	 try
	 {
		 driver.get(url); 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 System.out.println("Successfully navigate to the website");
	 }
	 catch(Exception e)
	 {
		 System.out.println("Error at navigating website");
	 }
}

public void Viewhomepage()
{
	String url = ("https://www.pwc.com.au/digitalpulse.html");  
    driver.get(url);  
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	String actualUrl = driver.getCurrentUrl();  
	       
	if (actualUrl.equals("https://www.pwc.com.au/digitalpulse.html"))
	{  
		System.out.println("Successfully view the home page");  
	}  
	else
	{  
		System.out.println("Failed to view home page");  
	}  
}

//Then I am presented with 3 columns of articles
public void articlescount() 
{
	try
	{
		List<WebElement> articles = driver.findElements(By.xpath("//div[contains(@class,'headline_column')]"));
	    System.out.println("I am presented with columns of articles " + articles.size());
	}
	catch(Exception e)
	{
		System.out.println("failed to verify the articles on homepage");  
	}
	
}

//And The ‘left’ column is displaying 2 articles 
public void validate_no_of_articles_on_left(){

	try
	{
		List<WebElement> left_column_articles = driver.findElements(By.xpath("//div[@class='headline_column2']/article"));
		System.out.println("The ‘left’ column is displaying articles " + left_column_articles.size());
	}
	catch(Exception e)
	{
		System.out.println("failed to verify left column articles");  
	}
}

//And the ‘middle’ column is displaying 1 articles 
public void validate_no_of_articles_on_middle(){
	try
	{
		List<WebElement> middle_column_articles = driver.findElements(By.xpath("//div[@class='headline_column1']"));
		System.out.println("The ‘middle’ column is displaying articles " + middle_column_articles.size());
	}
	catch(Exception e)
	{
		System.out.println("failed to verify middle column articles");  
	}
}

//And The ‘right’ column is displaying 4 articles
public void validate_no_of_articles_on_right(){
	try
	{
		List<WebElement> right_column_articles = driver.findElements(By.xpath("//div[@class='headline_column3']/article"));
		System.out.println("The ‘right’ column is displaying articles " + right_column_articles.size());
	}
	catch(Exception e)
	{
		System.out.println("failed to verify right column articles");  
	}
}

@Test
public void call_method() {
	
	navigatetowebsite();
	Viewhomepage();
	articlescount();
	validate_no_of_articles_on_left();
	validate_no_of_articles_on_middle();
	validate_no_of_articles_on_right();
	
	}
}
	


