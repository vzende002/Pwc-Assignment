//******Scenario-3******
//Given I navigate to the PwC Digital Pulse website
//When I click on "Magnifying glass icon"
//And I enter the text "Single page applications"
//And I submit the search
//Then I am taken to the search results page
//And I am presented with at least "1" search result
    
package Scenarios;

import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Search_functionality {

	WebDriver driver;

	@Before
	public void creatDriver() {
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vzende002\\Downloads\\Selenium downloads\\Drivers\\chromedriver.exe");  
	     driver=new ChromeDriver();  
	     driver.manage().window().maximize();  
	     
	    }

	public void Browser_close() 
	{
		driver.close();
		driver.quit();
	}

	@Test
	public void navigatetowebsite() {
		String url = ("https://www.pwc.com.au/digitalpulse/subscribe.html"); 
		 try
		 {
			 driver.get(url); 
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 System.out.println("Successfully navigate to the website");
		 }
		 catch(Exception e)
		 {
			 System.out.println("Error at navigating website");
		 }
			
		}
	
	
			
			//And I submit the search
			public void submit_search() {
				try {
					WebElement element = driver.findElement(By.xpath("//input[@class='submit-search']"));
					element.click();
					System.out.println("Successfully submitted search");
				}
				catch(Exception e) 
				{
					System.out.println("Failed to submit the search");
				}
			}
			
		
			//Then I am taken to the search results page
			public void search_page_result() {
				try {
					
					driver.findElement(By.xpath("//title[contains(text(),'Search results')]"));
					System.out.println("Successfully taken to serach results page");
				}
				catch(Exception e) 
				{
					System.out.println("Failed at search results page");
				}
			}
			
			//And I am presented with at least "1" search result
			public void search_result() {
				String count1;
			    try
			    {
			    	int result = driver.findElements(By.xpath("//div[contains(@class,'sr-with-img') or contains(@class,'pull-right')]")).size();
				    System.out.println(result); 
			    }
			    catch(Exception e)
			    {
			    	System.out.println("Failed to present atleast one search result"); 
			    }
			}
			
	}
	

	

